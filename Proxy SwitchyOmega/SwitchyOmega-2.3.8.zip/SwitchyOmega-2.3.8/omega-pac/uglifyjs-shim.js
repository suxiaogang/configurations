require('uglify-js-real');
module.exports = UglifyJS;
